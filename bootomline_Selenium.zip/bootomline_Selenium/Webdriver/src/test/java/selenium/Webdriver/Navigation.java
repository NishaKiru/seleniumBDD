package selenium.Webdriver;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Unit test for simple App.
 */
public class Navigation 
{
    /**
     * Rigorous Test :-)
     */
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(15,TimeUnit.seconds);
		//maximize the window
		driver.manage().window().maximize();
//launch the browser
	driver.get("https://www.mycontactform.com/samples.php");	
	driver.navigate().to("https://www.mycontactform.com/samples/basiccontact.php");
	driver.navigate().forward();
	driver.navigate().back();
	driver.navigate().refresh();
	
	
	driver.close();
	}
}
