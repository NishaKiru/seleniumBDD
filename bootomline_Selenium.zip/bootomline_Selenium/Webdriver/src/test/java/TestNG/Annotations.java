package TestNG;

import org.testng.annotations.*;

public class Annotations
{
    @BeforeSuite
    public void beforeSuite()
    {
        System.out.println("open the suite");
    }
    @AfterSuite
    public void AftereSuite()
    {
        System.out.println("close the suite");
    }
    @BeforeClass
    public void beforeClass()
    {
        System.out.println("opn the class");
    }
    @AfterClass
    public void afterClass()
    {
        System.out.println("closethe class");
    }

    @BeforeTest
    public void beforeTest()
    {
        System.out.println("opn the test");
    }
    @AfterTest
    public void afterTest()
    {
        System.out.println("close the test");
    }
    @BeforeMethod
    public void setup()
    {
        System.out.println("opn the test");
    }
    @AfterMethod
    public void teardown()
    {
        System.out.println("close");
    }
    @Test
    public void testcase()
    {
        System.out.println("test case 1");
    }
    @Test
    public void testcase1()
    {
        System.out.println("test case 2");
    }
    @Test
    public void testcase2()
    {
        System.out.println("test case 3");
    }

}
