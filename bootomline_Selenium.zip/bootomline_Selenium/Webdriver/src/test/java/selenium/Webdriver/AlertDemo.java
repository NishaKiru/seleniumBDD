package selenium.Webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Alert;
public class AlertDemo {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://demoqa.com/alerts");
      driver.findElement(By.id("alertButton")).click();


      Thread.sleep(2000);
      //alert handling
      Alert a=  driver.switchTo().alert();
      a.accept();
     // a.dismiss();
    }
}
