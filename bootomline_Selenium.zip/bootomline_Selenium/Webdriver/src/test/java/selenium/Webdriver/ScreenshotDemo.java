package selenium.Webdriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import ru.yandex.qatools.ashot.shooting.ShootingStrategy;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class ScreenshotDemo {

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// maximize the window
		driver.manage().window().maximize();
        //launch the browser
		driver.get("https://www.mycontactform.com/samples.php");
		
		//screenshot for entire page
ru.yandex.qatools.ashot.Screenshot scr=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
ImageIO.write(scr.getImage(),"jpg",new File("E://fullscreen.jpg"));

//selected component
WebElement logo=driver.findElement(By.xpath("//div[@id='header']/h1/span[@class='bold']"));
		ru.yandex.qatools.ashot.Screenshot logscr=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
				.coordsProvider(new WebDriverCoordsProvider())
				.takeScreenshot(driver,logo);
		ImageIO.write(logscr.getImage(),"jpg",new File("E://logscreen.jpg"));

		//viewable area
		TakesScreenshot screenshot=((TakesScreenshot)driver);
		File source=screenshot.getScreenshotAs(OutputType.FILE);
FileUtils.copyFile(source,new File("E://scree.jpg"));
	}

}
