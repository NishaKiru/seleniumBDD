package selenium.Webdriver;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Set;

public class Dynamixpath {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
       driver.get("https://www.amazon.in/");
     /*   driver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]/span")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@id='hmenu-content']//ul//li[7]//a//div")).click();
        driver.findElement(By.xpath("//div[@id='hmenu-content']//ul[2]//li[3]//a")).click();*/

        driver.findElement(By.xpath("//div[@class='nav-fill']/div/input[@id='twotabsearchtextbox']")).sendKeys("mobiles");
        Actions act = new Actions(driver);
        act.sendKeys(Keys.DOWN, Keys.ENTER).build().perform();
        List<WebElement> headings = driver.findElements(By.xpath("//h2[@class='a-size-mini a-spacing-none a-color-base s-line-clamp-2']//a//span"));
        System.out.println(headings.size());
        for (WebElement title : headings) {
            System.out.println(title.getText());
        }
    }
}