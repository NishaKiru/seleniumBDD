package selenium.Webdriver;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavascriptExecutors {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.browserstack.com/users/sign_in");
       JavascriptExecutor js= (JavascriptExecutor)driver;

       js.executeScript("document.getElementById('user_email_login').value='nsnisha@gmail.com';");
       js.executeScript("document.getElementById('user_password').value='nisha';");
        js.executeScript("document.getElementById('user_submit').click();");
        js.executeScript("alert('enter the correct login');");
        driver.close();
    }
}
