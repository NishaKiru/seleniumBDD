package selenium.Webdriver;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class HeadlessBrowser {
    public static void main(String[] args) {
        //chrome options
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        ChromeOptions options=new ChromeOptions();
        options.addArguments("headless");
        ChromeDriver driver=new ChromeDriver(options);
//HTMLUNITDriver
        HtmlUnitDriver driver1=new HtmlUnitDriver(BrowserVersion.CHROME);
        driver1.get("https://www.mycontactform.com/samples.php");

        // maximize the window
      //  driver.manage().window().maximize();
        //driver.get("https://www.mycontactform.com/samples.php");
       // System.out.println(driver.getTitle());
    }
}
