package selenium.Webdriver;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrokenLinks {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// maximize the window
		driver.manage().window().maximize();
        //launch the browser
		driver.get("https://www.mycontactform.com/samples.php");
		
		driver.findElement(By.linkText("Basic Contact Form")).click();
		driver.findElement(By.partialLinkText("Basic")).click();
		
	int size_of_links=	driver.findElements(By.xpath("//*[@id=\"left_col_top\"]/ul/li/a")).size();
		
		System.out.println(size_of_links);
	int n=	driver.findElements(By.xpath("//*[@id=\"left_col_top\"]/ul")).size();
		for(int i=1;i<=n;i++)
		{
	int a=driver.findElements(By.xpath("//*[@id=\"left_col_top\"]/ul["+i+"]/li/a")).size();
	for(int j=1;j<=a;j++)
	{
		
	driver.findElement(By.xpath("//*[@id=\"left_col_top\"]/ul["+i+"]/li["+j+"]/a")).click();
	
	TakesScreenshot screenshot=((TakesScreenshot)driver);
	File source=screenshot.getScreenshotAs(OutputType.FILE);
FileUtils.copyFile(source,new File("E://scree"+System.currentTimeMillis()+"jpg"));
	}
		
	}

}
}