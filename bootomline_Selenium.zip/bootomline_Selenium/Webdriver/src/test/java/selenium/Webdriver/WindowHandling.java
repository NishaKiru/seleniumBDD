package selenium.Webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.*;
public class WindowHandling {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.naukri.com/");

        String parent=driver.getWindowHandle();
        System.out.println(parent);
       Set<String> windows=driver.getWindowHandles();

//click login-------> 15


       Iterator<String> itr=windows.iterator();
       while(itr.hasNext())
       {
           String chi_window=itr.next();
           driver.switchTo().window(chi_window);
driver.switchTo().defaultContent();
           driver.close();
       }
    }
}
