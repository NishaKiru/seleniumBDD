package TestNG;

import org.testng.annotations.Test;

public class Seconds {
    @Test(priority=1)
    public void login()
    {
        System.out.println("login success");
    }
    @Test(priority=2,enabled = false)
    public void application()
    {
        System.out.println("first test case");
    }
    @Test(priority = 3)
    public void logout()
    {
        System.out.println("logout");
    }
    @Test
    public void demo()
    {
        System.out.println("demo");
    }
}
