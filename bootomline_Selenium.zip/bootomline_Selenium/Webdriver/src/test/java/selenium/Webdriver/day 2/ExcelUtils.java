package selenium.Webdriver;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.openqa.selenium.By;
public class ExcelUtils {
    public static void main(String[] args) throws IOException {
        String path="C:\\Users\\91978\\Desktop\\data.xlsx";
        FileInputStream fis =new FileInputStream(path);
        Workbook wb = new XSSFWorkbook(fis) ;//.xlsx
        Sheet sheet1=wb.getSheetAt(0);//select the particular sheet index(starting from 0)

    Row row=sheet1.getRow(0);
    Cell cell=row.getCell(0);
    Cell cell1=row.getCell(1);
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.browserstack.com/users/sign_in");

        driver.findElement(By.id("user_email_login")).sendKeys(cell.getStringCellValue());
        driver.findElement(By.id("user_password")).sendKeys(cell1.getStringCellValue());
        driver.close();
    }
}
