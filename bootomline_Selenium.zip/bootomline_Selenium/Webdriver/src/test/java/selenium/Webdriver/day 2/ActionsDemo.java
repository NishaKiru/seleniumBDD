package selenium.Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ActionsDemo
{
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.browserstack.com/");
       /*WebElement products= driver.findElement(By.xpath("//*[@id=\"product-menu-toggle\"]"));
       Actions act=new Actions(driver);
       act.moveToElement(products).build().perform();
       Thread.sleep(2000);
       driver.findElement(By.xpath("//*[@id=\"product-menu-dropdown\"]/div[1]/ul[1]/li[3]/a/div[2]")).click();*/
       //Double click
        WebElement free_trial= driver.findElement(By.xpath("//*[@id=\"free-trial-link-anchor\"]"));
        Actions act=new Actions(driver);
        act.doubleClick(free_trial).build().perform();


    }
}
