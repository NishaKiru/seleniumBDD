package selenium.Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasicInteraction {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// maximize the window
		driver.manage().window().maximize();
        //launch the browser
		driver.get("https://www.mycontactform.com/samples.php");
		
		driver.findElement(By.name("email_to[]")).click();

		driver.findElement(By.xpath("//*[@id=\"contactForm\"]/table/tbody/tr[1]/td/div/input[2]")).click();
		driver.findElement(By.id("subject")).sendKeys("email");

//dropdown

		WebElement ele = driver.findElement(By.id("q3"));
		System.out.println(ele.getText());
		WebDriverWait wait=new WebDriverWait(driver,20);
//wait.until(ExpectedConditions.visibilityOfAllElements(By.xpath("xpath for dopdown")));
		Select s = new Select(ele);
		s.selectByVisibleText("Second Option");

		// radiobutton

		driver.findElement(By.xpath("//input[@value=\"Second Option\"]")).click();
		// button
		driver.findElement(By.name("submit")).click();
		driver.close();// active window
		driver.quit();// close the entire browser
	}

}
