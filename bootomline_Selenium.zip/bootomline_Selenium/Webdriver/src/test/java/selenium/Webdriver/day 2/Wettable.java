import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Wettable
{
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("http://demo.guru99.com/test/web-table-element.php");
       int row= driver.findElements(By.xpath("//*[@id=\"leftcontainer\"]/table/tbody/tr")).size();
System.out.println(row);


for(int i=1;i<=row;i++)
{
    int col=driver.findElements(By.xpath("//*[@id='leftcontainer']/table/tbody/tr["+i+"]")).size();
    for(int j =1; j<=col; j++)
    {
       String data= driver.findElement(By.xpath("//*[@id='leftcontainer']/table/tbody/tr["+i+"]/td["+j+"]/a")).getText();
       System.out.println(data);
    }
}

    }
}
