package TestNG;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
/*open the browser
login--v=credential
close */

public class Firsts {
    WebDriver driver;
   @BeforeMethod
    public void setup()
    {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
       driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.reddit.com/");
    }
   @Test

    public void unsuccesfulLogin()
   {
       driver.findElement(By.xpath("//a[contains(@class,'_3Wg53T10KuuPmyWOMWsY2F')]")).click();
       WebElement frame_name= driver.findElement(By.className("_25r3t_lrPF3M6zD2YkWvZU"));
       driver.switchTo().frame(frame_name);

       driver.findElement(By.xpath("//input[contains(@d,'loginUsername')]")).sendKeys("nisha@gmail.com");
   }
@Test
    public void unsuccesfullogin()
    {
        driver.findElement(By.xpath("//a[contains(@class,'_3Wg53T10KuuPmyWOMWsY2F')]")).click();
        WebElement frame_name= driver.findElement(By.className("_25r3t_lrPF3M6zD2YkWvZU"));
        driver.switchTo().frame(frame_name);

        driver.findElement(By.xpath("//input[contains(@id,'loginUsername')]")).sendKeys("");
    }
@AfterMethod
    public void teardown()
   {
       driver.close();
   }
}
