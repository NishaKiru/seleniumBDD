package selenium.Webdriver;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class contextClickDemo {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.browserstack.com/");
        ((JavascriptExecutor)driver).executeScript("scroll(0,300)");
WebElement live=driver.findElement(By.xpath("//*[@id=\"post-26\"]/div[1]/div[1]/div/div/article/div/div/div/div[2]/div/div[1]/div[2]/div[1]/div/a"));
Actions act=new Actions(driver);
act.contextClick(live).build().perform();

act.sendKeys(Keys.DOWN,Keys.DOWN,Keys.ENTER).build().perform();
    }
}
