package TestNG;

import org.testng.annotations.Test;

public class dependsOnMethod {
    @Test
    public void Register()
    {
        System.out.println("successfull register");
    }
    @Test(dependsOnMethods = {"Register"})
    public void Login()
    {
        System.out.println("successful login");
    }
    @Test(dependsOnMethods = {"Login"})
public void profile()

{
System.out.println("welcome to my profile");
}
}
