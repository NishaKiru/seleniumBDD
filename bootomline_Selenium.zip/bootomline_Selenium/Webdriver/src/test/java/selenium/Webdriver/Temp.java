package selenium.Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.IOException;
import org.openqa.selenium.WebElement;
import java.util.*;
public class Temp {
    public static void main(String[] args) throws IOException, InterruptedException {

        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.zostel.com/");
        Thread.sleep(3000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,450)", "");
        driver.findElement(By.id("//div[@class='booking-w-lg__row w-29']//div//select//option")).click();
        Thread.sleep(2000);
     List<WebElement> options=driver.findElements(By.xpath("//ul[@class='select-options']//li"));
     for(WebElement ele:options)
     {
         if(ele.getText().contains("Bangalore"));
         ele.click();
     }
    }
}