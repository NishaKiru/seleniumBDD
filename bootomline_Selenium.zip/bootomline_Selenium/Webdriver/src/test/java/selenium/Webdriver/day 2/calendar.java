package selenium.Webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.*;
public class calendar {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "E:\\SeleniumJARs\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        // maximize the window
        driver.manage().window().maximize();
        //launch the browser
        driver.get("https://www.path2usa.com/travel-companions");
driver.findElement(By.id("travel_date")).click();
List<WebElement> days=driver.findElements(By.className("day"));
int count=days.size();
for(int i=0;i<count;i++)
{
    String text=driver.findElements(By.className("day")).get(i).getText();
    if(text.equalsIgnoreCase("24"))
    {
        driver.findElements(By.className("day")).get(i).click();
    }
}
    }
}
