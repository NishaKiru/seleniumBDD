package TestNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProviders {


    @Test(dataProvider = "details")
    public void display(String name, String pass)
    {
        System.out.println(name);
        System.out.println(pass);

    }
    @DataProvider(name="details")
    public Object[][] display()
    {
        return new Object[][]{
                {"nisha","passs"},
                {"nisha1","pass1"}
        };
    }


}
